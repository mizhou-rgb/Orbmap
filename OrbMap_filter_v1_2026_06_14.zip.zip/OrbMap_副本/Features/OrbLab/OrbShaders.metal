#include <metal_stdlib>
#include <SwiftUI/SwiftUI_Metal.h>
using namespace metal;

// MARK: - Coordinate helpers

float2 orbPoint(float2 position, float4 bounds) {
    float2 center = bounds.xy + bounds.zw * 0.5;
    float radius = min(bounds.z, bounds.w) * 0.5;
    return (position - center) / radius;
}

float2 orbPosition(float2 point, float4 bounds) {
    float2 center = bounds.xy + bounds.zw * 0.5;
    float radius = min(bounds.z, bounds.w) * 0.5;
    return center + point * radius;
}

float2 orbSourceUV(float2 point, float photoRange) {
    float radius = length(point);
    float radiusSquared = min(radius * radius, 0.999);
    float sphereDepth = sqrt(1.0 - radiusSquared);

    // Keep the center readable while compressing the outer image like a lens.
    float refraction = mix(0.84, 0.50, 1.0 - sphereDepth);
    float2 lensPoint = point * refraction;

    // Continuous angular bending creates a wrapped shell without a 2-pi seam.
    float angle = atan2(point.y, point.x);
    float shell = smoothstep(0.30, 0.94, radius);
    float2 tangent = float2(-sin(angle), cos(angle));
    float2 radial = float2(cos(angle), sin(angle));
    float angularBend = sin(angle * 2.0 + 0.30) * 0.11 * shell * shell;
    float2 wrappedPoint = lensPoint
        + tangent * angularBend
        - radial * (0.10 * shell * shell);

    float shellMix = smoothstep(0.22, 0.76, radius);
    float2 sourcePoint = mix(point * 0.76, wrappedPoint, shellMix);
    sourcePoint *= max(photoRange, 0.1);
    return clamp(0.5 + sourcePoint * 0.5, float2(0.002), float2(0.998));
}

float2 fittedImageUV(float2 imageUV, float aspectRatio) {
    float safeAspectRatio = max(aspectRatio, 0.001);
    float2 fittedSize = safeAspectRatio >= 1.0
        ? float2(1.0, 1.0 / safeAspectRatio)
        : float2(safeAspectRatio, 1.0);
    float2 fittedOrigin = (1.0 - fittedSize) * 0.5;
    return fittedOrigin + imageUV * fittedSize;
}

// MARK: - 31-tap Gaussian

half4 gaussian31(
    float2 position,
    SwiftUI::Layer layer,
    float2 axis,
    float sigma
) {
    float safeSigma = max(sigma, 0.01);
    float inverseVariance = 0.5 / (safeSigma * safeSigma);
    float centerWeight = 1.0;
    half4 accumulatedColor = layer.sample(position) * half(centerWeight);
    float accumulatedWeight = centerWeight;

    // Pair adjacent Gaussian taps into one linearly filtered sample. This
    // preserves the 31-tap kernel while reducing 31 texture reads to 17.
    for (int index = 1; index <= 13; index += 2) {
        float firstOffset = float(index);
        float secondOffset = float(index + 1);
        float firstWeight = exp(
            -(firstOffset * firstOffset) * inverseVariance
        );
        float secondWeight = exp(
            -(secondOffset * secondOffset) * inverseVariance
        );
        float pairWeight = firstWeight + secondWeight;
        float pairedOffset = (
            firstOffset * firstWeight
            + secondOffset * secondWeight
        ) / pairWeight;

        accumulatedColor += (
            layer.sample(position + axis * pairedOffset)
            + layer.sample(position - axis * pairedOffset)
        ) * half(pairWeight);
        accumulatedWeight += pairWeight * 2.0;
    }

    float outerWeight = exp(-225.0 * inverseVariance);
    accumulatedColor += (
        layer.sample(position + axis * 15.0)
        + layer.sample(position - axis * 15.0)
    ) * half(outerWeight);
    accumulatedWeight += outerWeight * 2.0;

    return accumulatedColor / half(accumulatedWeight);
}

[[ stitchable ]]
half4 gaussianBlurHorizontal31(
    float2 position,
    SwiftUI::Layer layer,
    float radius,
    float sigma
) {
    float spacing = max(radius, 0.0) / 15.0;
    return gaussian31(position, layer, float2(spacing, 0.0), sigma);
}

[[ stitchable ]]
half4 gaussianBlurVertical31(
    float2 position,
    SwiftUI::Layer layer,
    float radius,
    float sigma
) {
    float spacing = max(radius, 0.0) / 15.0;
    return gaussian31(position, layer, float2(0.0, spacing), sigma);
}

// MARK: - Rectangular image to seam-free orb surface

[[ stitchable ]]
half4 orbRemap(
    float2 position,
    SwiftUI::Layer layer,
    float4 bounds,
    float aspectRatio,
    float photoRange
) {
    float2 imageUV = orbSourceUV(
        orbPoint(position, bounds),
        photoRange
    );
    float2 sourceUV = fittedImageUV(imageUV, aspectRatio);
    return layer.sample(bounds.xy + sourceUV * bounds.zw);
}

// MARK: - Independent RGB shifts

[[ stitchable ]]
half4 orbBlueShift(
    float2 position,
    SwiftUI::Layer layer,
    float4 bounds,
    float2 offset
) {
    float2 point = orbPoint(position, bounds);
    float edgeInfluence = smoothstep(0.10, 0.92, length(point));
    offset *= mix(0.65, 1.0, edgeInfluence);

    half4 center = layer.sample(position);
    half4 shifted = layer.sample(position + offset);
    return half4(center.r, center.g, shifted.b, center.a);
}

[[ stitchable ]]
half4 orbRedShift(
    float2 position,
    SwiftUI::Layer layer,
    float4 bounds,
    float2 offset
) {
    float2 point = orbPoint(position, bounds);
    float leftBias = smoothstep(0.85, -0.70, point.x);
    offset *= mix(0.45, 1.0, leftBias);

    half4 center = layer.sample(position);
    half4 shifted = layer.sample(position + offset);
    return half4(shifted.r, center.g, center.b, center.a);
}

// MARK: - Independent surface distortions

float2 inverseWaterUndulation(
    float2 point,
    float amount,
    float frequency,
    float phase,
    float2 direction
) {
    float2 primaryDirection = normalize(direction);
    float2 secondaryDirection = normalize(
        float2(-primaryDirection.y, primaryDirection.x) * 0.65
        + primaryDirection * 0.35
    );

    float primaryPhase = dot(point, primaryDirection) * frequency - phase;
    float secondaryPhase = dot(point, secondaryDirection)
        * frequency
        * 0.58
        + phase
        * 0.43
        + 1.40;

    // Refract along the gradient of two broad crossing wave fields. This gives
    // smooth water movement without circular rings or repeated embossed bands.
    float2 primaryGradient = primaryDirection
        * cos(primaryPhase)
        * frequency;
    float2 secondaryGradient = secondaryDirection
        * cos(secondaryPhase)
        * frequency
        * 0.58;
    float2 surfaceGradient = primaryGradient * 0.68
        + secondaryGradient * 0.32;

    float silhouetteFade = 1.0 - smoothstep(0.82, 1.0, length(point));
    float slowLift = 0.86
        + 0.14 * sin(point.y * 1.25 - phase * 0.12);
    float refractionStrength = amount * 0.115 * silhouetteFade * slowLift;
    return point - surfaceGradient * refractionStrength;
}

[[ stitchable ]]
half4 orbLowerLeftRipple(
    float2 position,
    SwiftUI::Layer layer,
    float4 bounds,
    float amount,
    float frequency,
    float phase
) {
    float2 point = orbPoint(position, bounds);
    float2 sourcePoint = inverseWaterUndulation(
        point,
        amount,
        frequency,
        phase,
        float2(1.0, 0.34)
    );
    return layer.sample(orbPosition(sourcePoint, bounds));
}

[[ stitchable ]]
half4 orbPinch(
    float2 position,
    SwiftUI::Layer layer,
    float4 bounds,
    float strength
) {
    float2 point = orbPoint(position, bounds);
    float2 center = float2(0.02, -0.02);
    float pinchRadius = 1.68;
    float2 delta = point - center;
    float distanceFromCenter = length(delta);

    if (distanceFromCenter < 0.0001 || distanceFromCenter >= pinchRadius) {
        return layer.sample(position);
    }

    float normalizedDistance = distanceFromCenter / pinchRadius;
    float falloff = pow(1.0 - normalizedDistance, 2.0);
    float scale = max(0.18, 1.0 - strength * falloff * 0.58);
    float2 sourcePoint = center + delta * scale;
    return layer.sample(orbPosition(sourcePoint, bounds));
}

[[ stitchable ]]
half4 orbRightDownRipple(
    float2 position,
    SwiftUI::Layer layer,
    float4 bounds,
    float amount,
    float frequency,
    float phase
) {
    float2 point = orbPoint(position, bounds);
    float2 shiftedPoint = point - float2(0.24, 0.18);
    float2 sourcePoint = inverseWaterUndulation(
        shiftedPoint,
        amount,
        frequency,
        phase + 1.85,
        float2(-0.34, 0.94)
    );
    sourcePoint += float2(0.24, 0.18);
    return layer.sample(orbPosition(sourcePoint, bounds));
}

// MARK: - Vignette and exposure

[[ stitchable ]]
half4 orbVignette(
    float2 position,
    SwiftUI::Layer layer,
    float4 bounds,
    float amount,
    float size,
    float falloff
) {
    float radius = length(orbPoint(position, bounds));
    if (radius > 1.0) {
        return half4(0.0h);
    }

    half4 color = layer.sample(position);
    float fadeStart = clamp(size, 0.05, 0.98);
    float fadeEnd = clamp(fadeStart + falloff, fadeStart + 0.01, 1.08);
    float radialLight = 1.0 - smoothstep(fadeStart, fadeEnd, radius);
    float vignette = mix(1.0, radialLight, clamp(amount, 0.0, 1.0));

    // Color darkens broadly, while alpha remains crisp at the physical orb edge.
    float edgeAlpha = 1.0 - smoothstep(0.782, 1.0, radius);
    half alpha = color.a * half(edgeAlpha);
    return half4(color.rgb * half(vignette) * alpha, alpha);
}

[[ stitchable ]]
half4 orbExposure(
    float2 position,
    half4 color,
    float exposure,
    float gamma,
    float gamutMap
) {
    if (color.a <= 0.0h) {
        return color;
    }

    float alpha = float(color.a);
    float3 straightColor = float3(color.rgb) / max(alpha, 0.0001);
    straightColor = max(straightColor, float3(0.0));
    straightColor *= exp2(exposure);
    straightColor = pow(straightColor, float3(1.0 / max(gamma, 0.01)));
    straightColor = straightColor
        / (float3(1.0) + straightColor * max(gamutMap, 0.0));
    return half4(half3(straightColor * alpha), color.a);
}
