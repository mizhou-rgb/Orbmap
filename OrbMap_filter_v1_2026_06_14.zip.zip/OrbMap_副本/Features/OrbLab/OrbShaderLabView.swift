import SwiftUI
import PhotosUI
import UIKit

struct OrbShaderLabView: View {
    private let previewSize: CGFloat = 320

    @State private var selectedPhoto: PhotosPickerItem?
    @State private var selectedImage: UIImage?
    private let parameters = OrbShaderParameters()

    var body: some View {
        ZStack {
            Color.black
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 24) {
                    orbPreview
                        .padding(.top, 36)

                    Text("Effect-style ORB Pipeline")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.55))

                    PhotosPicker(
                        selection: $selectedPhoto,
                        matching: .images
                    ) {
                        Label("选择测试照片", systemImage: "photo.on.rectangle")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.white)
                    .foregroundStyle(.black)

                }
                .padding(.horizontal, 24)
                .padding(.bottom, 32)
            }
        }
        .task(id: selectedPhoto) {
            await loadSelectedPhoto()
        }
    }

    @ViewBuilder
    private var orbPreview: some View {
        if let image = selectedImage ?? loadSampleImage() {
            OrbImageView(
                image: Image(uiImage: image),
                imageAspectRatio: image.size.width / image.size.height,
                size: previewSize,
                parameters: parameters
            )
        } else {
            ContentUnavailableView(
                "找不到测试照片",
                systemImage: "photo",
                description: Text("请将 sample_photo 或 orb_lab_image 加入 OrbMap Target。")
            )
            .foregroundStyle(.white)
            .frame(width: previewSize, height: previewSize)
        }
    }

    private func loadSampleImage() -> UIImage? {
        let candidates = [
            (name: "sample_photo", extension: "jpg"),
            (name: "sample_photo", extension: "png"),
            (name: "orb_lab_image", extension: "jpg")
        ]

        for candidate in candidates {
            if let url = Bundle.main.url(
                forResource: candidate.name,
                withExtension: candidate.extension
            ), let image = UIImage(contentsOfFile: url.path) {
                return image
            }
        }

        return nil
    }

    private func loadSelectedPhoto() async {
        guard let selectedPhoto else {
            return
        }

        guard let data = try? await selectedPhoto.loadTransferable(type: Data.self),
              let image = UIImage(data: data) else {
            return
        }

        selectedImage = image
    }
}

#Preview {
    OrbShaderLabView()
}
